/* 
 * File:   ControlLib.h
 * Author: harntson
 *
 * Created on February 25, 2015, 11:57 AM
 */

#ifndef CONTROLLIB_H
#define	CONTROLLIB_H

#include "ADC.h"
#include "ControlLib.h"


//include all functions

#endif	/* CONTROLLIB_H */

