/* 
 * File:   test.h
 * Author: ajgriesemer
 *
 * Created on April 27, 2014, 7:25 PM
 */

#ifndef TEST_H
#define	TEST_H

void test_passthrough(void);
void test_passthroughburst(void);
void test_motor(void);
void test_plotter(void);
void test_PWMPlotter(void);
void test_HeartBeat(void);
void test_UART(void);
void test_encoder(void);
void test_MayDay(void);
#endif	/* TEST_H */

