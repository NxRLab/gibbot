#include "p33Fxxxx.h"
#include "p30fxxxx.h"

AD1CON1bits.AD12B=0;
