
#ifndef GIBBOT_H
#define	GIBBOT_H

/*
 * QEI Motor A     RP69/RD5
 * QEI Motor B     RP68/RD4
 * QEI TopMag A    RPI32/RB0
 * QEI TopMag B    RPI33/RB1
 * QEI BotMag A    RPI120/RG8
 * QEI BotMag B    RPI119/RG7
 * dsPIC SCL       SCL2/RF5
 * dsPIC SDA       SDA2/RF4
 * LED 1           RD11
 * LED 2           RD0
 * LED 3           RC13
 * LED 4           RC14
 * Top Magnet      RD10
 * Low Magnet      RB15
 * User            RB2
 */

#define S1 PORTDbits.RD3
#define S2 PORTDbits.RD2
#define S3 PORTDbits.RD1

#define USER PORTBbits.RB2
#define LOWMAG PORTBbits.RB15

#define LED1 LATDbits.LATD11
#define LED2 LATDbits.LATD0
#define LED3 LATCbits.LATC13
#define LED4 LATCbits.LATC14

extern int error;
extern int transmit;
#endif	/* GIBBOT_H */

