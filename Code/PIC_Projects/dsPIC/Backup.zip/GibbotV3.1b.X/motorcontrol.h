/*
 * File:   motorcontrol.h
 * Author: ajgriesemer
 *
 * Created on September 3, 2013, 12:34 PM
 */

#ifndef MOTORCONTROL_H
#define	MOTORCONTROL_H

void High(int pin);
void Low(int pin);
void Float(int pin);
void commutate(int state);
#endif	/* MOTORCONTROL_H */

