#ifndef GIBBOT_H
#define	GIBBOT_H

void init_clock(void);

#endif	/* GIBBOT_H */

