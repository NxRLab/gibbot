#include <stdio.h>
#include <stdlib.h>
#include <p33Exxxx.h>
#include "gibbot.h"

/* This function initializes the internal clock to 80MHz  *
 * based on an 8MHz external crystal oscillator           */
void init_clock(void){

}