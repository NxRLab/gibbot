#ifndef ADC_H
#define	ADC_H

void initialize_ADC(void);
unsigned short read_ADC(void);
void initialize_ADC_Single(void);
unsigned short ADC_Read_Single(void);

#endif	/* ADC_H */

