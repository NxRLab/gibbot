#ifndef TEMPERATURE_H
#define	TEMPERATURE_H

float motor_temp(float resistance);
float thermistor_resistance(void);

#endif	/* TEMPERATURE_H */