#ifndef ENCODER_H
#define	ENCODER_H

void initialize_QEI(void);
void read_encoder(void);
#endif	/* ENCODER_H */

