#ifndef CURRENTSENSOR_H
#define	CURRENTSENSOR_H

void initialize_ADC(void);
unsigned short read_ADC(void);

#endif	/* CURRENTSENSOR_H */

