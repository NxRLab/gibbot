#ifndef TEMPERATURE_H
#define	TEMPERATURE_H

float read_motor_temp(void);

#endif	/* TEMPERATURE_H */